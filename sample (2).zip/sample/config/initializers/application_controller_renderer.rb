# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '8debc993b36e246d1426dbf096500149f4a5765e4280d6dc2bdf0e0d7b781e1c34cfae3c00efc5919404f805f26a3f0aaf10cd45e393e98bb5490806e8a858f2'
