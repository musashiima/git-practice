# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'b2731991dd0bf7331a9a39c34ce25b504c343d80c4ce74de0144eb32810f94f502134e14e7429a5d79ebadfb1fd36502ef24c1d219e988b602dcdf194300db86'